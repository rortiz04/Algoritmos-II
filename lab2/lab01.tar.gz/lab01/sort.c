#include <stdio.h>
#include "sort.h"

bool array_is_sorted(int array[], unsigned int length)
{
	printf("Falta completar! array=%p length=%u\n", (void*)array, length);
	return false;
}

void insertion_sort(int array[], unsigned int length)
{
    	printf("Falta completar! array=%p length=%u\n", (void*)array, length);
}

void selection_sort(int array[], unsigned int length)
{
	printf("Falta completar! array=%p length=%u\n", (void*)array, length);
}

void quick_sort(int array[], unsigned int length)
{
	printf("Falta completar! array=%p length=%u\n", (void*)array, length);
}


